package com.infinitisys.royalbluepos.adapters;

/**
 * Created by anupamchugh on 11/02/17.
 */

public class DataModel {


    public int id;
    public String text;
    public int drawable;
    public String color;

    public DataModel(int i,String t, int d, String c )
    {
        id = i;
        text=t;
        drawable=d;
        color=c;
    }
}

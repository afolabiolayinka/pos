package com.infinitisys.royalbluepos.ui.paywithnfc;

import androidx.lifecycle.ViewModel;

public class PayWithNfcViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
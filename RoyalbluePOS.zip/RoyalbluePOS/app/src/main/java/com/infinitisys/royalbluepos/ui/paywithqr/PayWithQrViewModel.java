package com.infinitisys.royalbluepos.ui.paywithqr;

import androidx.lifecycle.ViewModel;

public class PayWithQrViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
package com.infinitisys.royalbluepos;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.infinitisys.royalbluepos.databinding.ActivityPaymentBinding;
import com.infinitisys.royalbluepos.sdk.ByteUtil;
import com.infinitisys.royalbluepos.sdk.PosApiHelper;

import java.util.Arrays;

public class PaymentActivity extends AppCompatActivity {

    private ActivityPaymentBinding binding;
    public static final String TAG = PaymentActivity.class.getSimpleName();

    PosApiHelper mPosApiHelper = PosApiHelper.getInstance();
    private WorkHandler mWorkHandler;
    private HandlerThread mWorkThread;
    private Bitmap mKeypadLogo = null;
    private boolean mThreadFinished = false;
    private byte track1[] = new byte[250];
    private byte track2[] = new byte[250];
    private byte track3[] = new byte[250];

    Button proceedBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityPaymentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_card, R.id.navigation_nfc, R.id.navigation_qr)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_payment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

        proceedBtn = (Button) findViewById(R.id.proceedBtn);
        proceedBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mWorkHandler.sendEmptyMessage(WorkHandler.MSG_TEST_EMV);
            }
        });

        initEMV();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onResume() {
        //disable the power key
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        super.onResume();
        mPosApiHelper.InitPaySysKernel();

    }

    @Override
    protected void onPause() {
        //enable the power key
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mThreadFinished = true;

        mWorkHandler.removeCallbacksAndMessages(null);
        mWorkThread.quitSafely();

        mPosApiHelper.UninitPaySysKernel();
    }

    private void initEMV() {
        //star a thread for emv action
        mWorkThread = new HandlerThread("sdk_emv_thread");
        mWorkThread.start();
        mWorkHandler = new WorkHandler(mWorkThread.getLooper());

        mPosApiHelper.EmvEnvParaInit();
        mPosApiHelper.EmvClearAllCapks();
        mPosApiHelper.EmvClearAllAIDS();
    }

    private class WorkHandler extends Handler {

        public static final int MSG_TEST_EMV = 1;
        public static final int MSG_PIN_BLOCK = 2;
        public static final int MSG_DUKPTPIN_BLOCK = 3;

        public WorkHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            int what = msg.what;
            int ret;
            Log.e("TAG", "vpos*****************EmvEnvParaInit");

            switch (what) {
                case MSG_TEST_EMV:
                    Log.e("TAG", "vpos*****************Start EMV test");
                    showMessage("wait card ");
                    int mCardType = -1;
                    byte cardtype[] = new byte[3];
                    byte serialNo[] = new byte[50];
                    byte ATR[] = new byte[40];
                    byte PaypassTagBuff[] = new byte[1024];
                    mPosApiHelper.SetEntryModeOpen();
                    final long time = System.currentTimeMillis();
                    Log.e("TAG", "vpos*****************wait card");
                    while (System.currentTimeMillis() < time + 30 * 1000) {
                        if (mThreadFinished) {
                            Log.e("TAG", "vpos*****************loop detecting bIsBack 11");
                            mPosApiHelper.SetEntryModeClose();
                            return;
                        }

                        mCardType = mPosApiHelper.EntryPoint();
                        Log.d(TAG, "vpos EntryPoint mCardType== " + mCardType);
                        if (mCardType >= 0) {
                            break;
                        }
                    }

                    if (mCardType < 0)  {
                        Log.e(TAG, "vpos*************loop detecting return ");
                        mPosApiHelper.SetEntryModeClose();
                        showMessage("Not detected card! ");
                        return;
                    }

                    Log.d(TAG, "*************loop detecting return 00");
                    mPosApiHelper.SetEntryModeClose();
                    Log.e(TAG, "*************vpos loop detecting return11 ");

                    if (mCardType == -1) {
                        showMessage("timeOut~");
                        return;
                    } else if (mCardType == 0) {

                        Log.d(TAG, "Mcrtest start00");
                        String McrData = "";
                        Arrays.fill(track1, (byte) 0x00);
                        Arrays.fill(track2, (byte) 0x00);
                        Arrays.fill(track3, (byte) 0x00);
                        Log.e(TAG, "Mcrtest start22");
                        ret = mPosApiHelper.McrRead((byte) 0, (byte) 0, track1, track2, track3);
                        Log.e(TAG, "Mcrtest start44=" + ret);
                        if (ret >= 0) {
                            if ((ret & 0x01) == 0x01) {
                                McrData = "track1:" + new String(track1).trim();
                            }
                            if ((ret & 0x02) == 0x02) {
                                McrData = McrData + "\n\ntrack2:" + new String(track2).trim();
                            }
                            if ((ret & 0x04) == 0x04) {
                                McrData = McrData + "\n\ntrack3:" + new String(track3).trim();
                            }
                        } else {
                            McrData = "Lib_MsrRead check data error";
                        }
                        mPosApiHelper.McrClose();

                        showMessage("MCR:  " + McrData);

                        ///*******************-----EMV contact---******************************///
                    } else if (mCardType == 1) {

                        String Tag5A_data = "";
                        short TagCardNo = 0x5A;
                        int TagCardNo_len;
                        byte CardNoData[] = new byte[56];

                        mPosApiHelper.KeyPadInit(mKeypadLogo);
                        mPosApiHelper.SetKeyPadTime(20);

                        mPosApiHelper.EmvKernelInit();
                        mPosApiHelper.EmvSetTransType(1);
                        mPosApiHelper.EmvSetTransAmount(9879900);
                        mPosApiHelper.EmvSetCardType(1);

                        Log.d(TAG, "EMV TEST");

                        mPosApiHelper.SetKeyPadType(0);
                        ret = mPosApiHelper.EmvProcess(1, 0);  //The FLOWTYPE value is 1- simplifies the process
                        Log.d(TAG, "ret000 = " + ret);

                        if (ret < 0) {
                            showMessage("EMV Termination");
                            return;

                        } else if (ret == 3) {
                            Log.d(TAG, "EMV GOONLINE");
                        }

                        TagCardNo_len = mPosApiHelper.EmvGetTagData(CardNoData, 56, TagCardNo);

                        Log.d(TAG, "TagCardNo_len--::" + TagCardNo_len);
                        if (TagCardNo_len > 0) {
                            for (int i = 0; i < TagCardNo_len; i++) {
                                Log.d(TAG, "i = " + i + "  " + CardNoData[i]);
                                Tag5A_data += ByteUtil.byteToHexString(CardNoData[i] /*& 0xFF*/);
                            }

                            if (TagCardNo_len % 2 != 0) {
                                Tag5A_data = Tag5A_data.substring(0, TagCardNo_len * 2 - 1);
                            }

                            final int bypass = mPosApiHelper.EmvPinbyPass();

                            showMessage("EMV GOONLINE" + "\nCardNO:" + Tag5A_data  );
                        } else {
                            Log.d(TAG, "Termination");
                            showMessage("EMV Termination");

                        }
                        Log.d(TAG, "EmvFinal");
                        mPosApiHelper.EmvFinal();

                        ///*******************----Contactless-Quics and PayWave---******************************///
                    } else if (mCardType == 3) {

                        Log.d(TAG, "paywaveunipay0000");
                        String Tag57_data = "";
                        String strEmvStatus = "";
                        short TagCardNo = 0x57;
                        int TagCardNo_len;
                        byte CardNoData[] = new byte[56];

                        mPosApiHelper.KeyPadInit(mKeypadLogo);
                        mPosApiHelper.SetKeyPadTime(20);  //set pinpad timeout is 20 seconds

                        mPosApiHelper.PayWaveSetTransType(0x00);
                        mPosApiHelper.PayWaveSetTransAmount(11000);

                        ret = mPosApiHelper.PayWaveTransProcess();

                        if (ret < 0) {
                            showMessage("Paywave Termination");
                            mPosApiHelper.PayWaveFinal();
                            return;

                        } else if (ret == 22) {
                            strEmvStatus = "Paywave GOONLINE";
                        } else if (ret == 101) {
                            strEmvStatus = "Paywave ACCEPTED_OFFLINE";
                        } else if (ret == 102) {
                            strEmvStatus = "Paywave DENIALED_OFFLINE";
                        }

                        TagCardNo_len = mPosApiHelper.PayWaveGetTagData(CardNoData, 56, TagCardNo);
                        Log.d(TAG, "TagCardNo_len : " + TagCardNo_len);
                        for (int i = 0; i < TagCardNo_len; i++) {
                            Log.d(TAG, "i = " + i + "  " + CardNoData[i]);
                            Tag57_data += ByteUtil.byteToHexString(CardNoData[i] /*& 0xFF*/);
                        }

                        if (TagCardNo_len % 2 != 0) {
                            Tag57_data = Tag57_data.substring(0, TagCardNo_len * 2 - 1);
                        }
                        Log.d(TAG, "-Tag57_data=----" + Tag57_data);


                        showMessage(strEmvStatus + "\n\nCardNO:" + Tag57_data);

                        mPosApiHelper.PayWaveFinal();


                        ///*******************---if (mCardType == 2) {---******************************///
                    } else if (mCardType == 2) {
                        Log.d(TAG, "Paypass Kernel Test");
                        int TagName = 0x5A; //PAN
                        String PaypssTag57_data = "";

                        int result = mPosApiHelper.PaypassTransaction();
                        Log.d(TAG, "Paypass PaypassTransaction ret->" + result);

                        int Data_len = mPosApiHelper.PaypassGetTagValue(PaypassTagBuff, 1024, TagName);
                        Log.d(TAG, "Paypass PaypassGetTagValue" + Data_len);

                        for (int i = 0; i < Data_len; i++) {
                            Log.d(TAG, "i = " + i + "  " + PaypassTagBuff[i]);
                            PaypssTag57_data += ByteUtil.byteToHexString(PaypassTagBuff[i] /*& 0xFF*/);
                        }

                        if (Data_len / 2 != 0) {
                            PaypssTag57_data = PaypssTag57_data.substring(0, Data_len * 2);
                        }

                        mPosApiHelper.PaypassFinal();

                        showMessage(PaypssTag57_data);

                    }

                    break;

                case MSG_PIN_BLOCK:
                    Log.d(TAG, "PinBlock0 ");

                    int pinkey_n = 0;
                    int timeout_s = 12;
                    //  byte[] card_no = new byte[]{0x34,0x30, 0x30, 0x32, 0x32, 0x31, 0x32,  0x30, 0x30, 0x30, 0x30, 0x31,0x39,0x38,0x35,0x32}; //4002212000019852
                    byte[] card_no = new byte[]{0x32, 0x32, 0x30, 0x30, 0x32, 0x34, 0x30, 0x36, 0x39, 0x39, 0x33, 0x30, 0x31, 0x30, 0x36, 0x31};
                    byte[] mode = new byte[]{1};
                    byte[] pin_block = new byte[8];

                    ret = mPosApiHelper.EmvGetPinBlock(0, pinkey_n, card_no, mode, pin_block, timeout_s);
                    Log.d(TAG, "PinBlock0 EmvGetPinBlock ret=" + ret);

                    if (ret != 0) {
                        showMessage("Pin Block Test Failed");
                        return;
                    }

                    final String pin_block00 = ByteUtil.bytearrayToHexString(pin_block, pin_block.length);

                    Log.d(TAG, "PinBlock2 pin_block00=----" + pin_block00);

                    showMessage("PinBlock0 :" + pin_block00);

                    break;

                case MSG_DUKPTPIN_BLOCK:
                    Log.d(TAG, "dukptPinBlock0 ");
                    int dukptpinkey_n = 2;
                    byte[] dukptcard_no = new byte[]{0x32, 0x32, 0x30, 0x30, 0x32, 0x34, 0x30, 0x36, 0x39, 0x39, 0x33, 0x30, 0x31, 0x30, 0x36, 0x31};
                    byte[] dukptmode = new byte[]{1};
                    byte[] dukptpin_block = new byte[8];
                    byte[] OutKsn = new byte[10];
                    byte[] PinKcv = new byte[3];
                    int timeout = 12;

                    ret = mPosApiHelper.EmvGetDukptPinblock(0, dukptpinkey_n, dukptcard_no, dukptpin_block, OutKsn, PinKcv, timeout);
                    Log.d(TAG, "dukptPinBlock0 EmvGetPinBlock ret=" + ret);
                    if (ret != 0) {
                        showMessage("dukptPin Block Test Failed");
                        return;
                    }

                    final String dukptpin_block00 = ByteUtil.bytearrayToHexString(dukptpin_block, dukptpin_block.length);
                    Log.d(TAG, "dukptPinBlock2 pin_block00=----" + dukptpin_block00);

                    final String ksn = ByteUtil.bytearrayToHexString(OutKsn, OutKsn.length);
                    Log.d(TAG, "dukptPinBlock2 OutKsn=----" + OutKsn);
                    showMessage("dukptPinBlock0 :" + dukptpin_block00 + "\r\nKsn:" + ksn);

                    break;

                default:
                    break;
            }
        }
    }

    public void showMessage(String message) {
        CharSequence text = message;
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(this, text, duration);
        toast.show();
    }

}
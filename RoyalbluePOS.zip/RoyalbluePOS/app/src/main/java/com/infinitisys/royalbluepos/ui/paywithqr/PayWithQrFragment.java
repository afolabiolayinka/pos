package com.infinitisys.royalbluepos.ui.paywithqr;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.infinitisys.royalbluepos.R;

public class PayWithQrFragment extends Fragment {

    private PayWithQrViewModel mViewModel;

    public static PayWithQrFragment newInstance() {
        return new PayWithQrFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_pay_with_qr, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(PayWithQrViewModel.class);
        // TODO: Use the ViewModel
    }

}
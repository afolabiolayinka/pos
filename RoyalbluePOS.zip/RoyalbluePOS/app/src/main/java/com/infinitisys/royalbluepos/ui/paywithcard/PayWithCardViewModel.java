package com.infinitisys.royalbluepos.ui.paywithcard;

import androidx.lifecycle.ViewModel;

public class PayWithCardViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
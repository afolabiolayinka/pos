package com.infinitisys.royalbluepos.database;

public class AppDatabase {
}

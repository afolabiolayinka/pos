package com.infinitisys.royalbluepos.ui.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.infinitisys.royalbluepos.PaymentActivity;
import com.infinitisys.royalbluepos.R;
import com.infinitisys.royalbluepos.adapters.DataModel;
import com.infinitisys.royalbluepos.adapters.RecyclerViewAdapter;
import com.infinitisys.royalbluepos.databinding.FragmentDashboardBinding;

import java.util.ArrayList;

public class DashboardFragment extends Fragment implements RecyclerViewAdapter.ItemListener {

    private FragmentDashboardBinding binding;

    RecyclerView recyclerView;
    ArrayList<DataModel> arrayList;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        DashboardViewModel dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);
        arrayList = new ArrayList<>();
        arrayList.add(new DataModel(1,"Purchase", R.drawable.ic_baseline_credit_card_24, "#09A9FF"));
        arrayList.add(new DataModel(2,"Pay Bills", R.drawable.ic_baseline_business_center_24, "#3E51B1"));
        arrayList.add(new DataModel(3,"Buy Airtime", R.drawable.ic_baseline_phone_forwarded_24, "#673BB7"));
        arrayList.add(new DataModel(4,"Wallet", R.drawable.ic_baseline_account_balance_wallet_24, "#4BAA50"));
        /*arrayList.add(new DataModel("Item 5", R.drawable.three_d, "#F94336"));
        arrayList.add(new DataModel("Item 6", R.drawable.terraria, "#0A9B88"));*/

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this.getContext(), arrayList, this);
        recyclerView.setAdapter(adapter);

        /**
         AutoFitGridLayoutManager that auto fits the cells by the column width defined.
         **/

        /*AutoFitGridLayoutManager layoutManager = new AutoFitGridLayoutManager(this.getContext(), 500);
        recyclerView.setLayoutManager(layoutManager);*/

        /**
         Simple GridLayoutManager that spans two columns
         **/
        GridLayoutManager manager = new GridLayoutManager(this.getContext(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);



        /*final TextView textView = binding.textDashboard;
        dashboardViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);*/
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    @Override
    public void onItemClick(DataModel item) {

        Intent intent;

        switch(item.id) {
            case 1:
                //showPaymentFragment();
                intent = new Intent(this.getContext(), PaymentActivity.class);
                startActivity(intent);
                break;
            case 2:
                //intent = new Intent(this.getContext(), PayBillsActivity.class);
                //startActivity(intent);
                //this.getActivity().finish();
                break;
            case 3:
                //intent = new Intent(this.getContext(), BuyAirtimeActivity.class);
                //startActivity(intent);
                //this.getActivity().finish();
                break;
            case 4:
                //intent = new Intent(this.getContext(), WalletActivity.class);
                //startActivity(intent);
                //this.getActivity().finish();
                break;
            default:
                Toast.makeText(this.getContext(), "No item selected", Toast.LENGTH_SHORT).show();
        }

    }
}